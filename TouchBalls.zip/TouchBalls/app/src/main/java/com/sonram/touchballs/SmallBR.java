package com.sonram.touchballs;

import android.content.Context;
import android.graphics.Color;
import android.graphics.Paint;

import java.util.Random;

public class SmallBR {
    Paint paint;
    int smallRX,smallRY,smallRspeed;
    Random random;

    public SmallBR() {
        paint = new Paint();
        paint.setColor(Color.rgb(0,179,89));
        paint.setAntiAlias(false);
        random = new Random();
        getsmallBR();

    }

    public void getsmallBR(){
        smallRX = TouchBallView.dWidth+21;
        smallRY = random.nextInt(TouchBallView.dHeight);
        smallRspeed = 5 +random.nextInt(10);

    }
}
