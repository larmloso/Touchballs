package com.sonram.touchballs;

import android.graphics.Color;
import android.graphics.Paint;

import java.util.Random;

public class KillballRight {
    Paint paint;
    int kbX,kbY,kbSpeed;
    Random random;

    public KillballRight() {
        paint = new Paint();
        paint.setColor(Color.rgb(0,0,0));
        paint.setAntiAlias(false);
        random = new Random();
        getkillbR();

    }

    public void getkillbR(){
        kbX = TouchBallView.dWidth+21;
        kbY = random.nextInt(TouchBallView.dHeight);
        kbSpeed = 5 +random.nextInt(5);
    }
}
