package com.sonram.touchballs;

import android.content.Context;
import android.graphics.Color;
import android.graphics.Paint;

import java.util.Random;

public class BallRight {
    Paint paint;
    int ballRX,ballRY,ballRspeed;
    Random random;

    public BallRight(Context context){
        paint = new Paint();
        paint.setColor(Color.rgb(255,20,147));
        paint.setAntiAlias(false);
        random = new Random();
        getBallRight();

    }
    public void getBallRight(){
        ballRX = TouchBallView.dWidth+21;
        ballRY = random.nextInt(TouchBallView.dHeight);
        ballRspeed = 5 +random.nextInt(10);

    }
}
