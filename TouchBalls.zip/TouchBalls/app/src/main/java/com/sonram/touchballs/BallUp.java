package com.sonram.touchballs;

import android.content.Context;
import android.graphics.Color;
import android.graphics.Paint;

import java.util.Random;

public class BallUp {
    Paint paint;
    int ballupX,ballupY,ballupSpeed;
    Random random;


    public BallUp(Context context){
        paint = new Paint();
        paint.setColor(Color.rgb(0,170,204));
        paint.setAntiAlias(false);
        random = new Random();
        getballup();
    }

    public void getballup(){
        ballupY = TouchBallView.dHeight + 21;
        ballupX = random.nextInt(TouchBallView.dWidth);
        ballupSpeed = 5 +random.nextInt(10);

    }
}
