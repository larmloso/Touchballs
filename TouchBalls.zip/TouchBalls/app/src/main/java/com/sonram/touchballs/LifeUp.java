package com.sonram.touchballs;

import android.content.Context;
import android.graphics.Color;
import android.graphics.Paint;

import java.util.Random;

public class LifeUp extends KillballRight {
    Paint paint;
    int lifeY,lifeX,lifespeed;
    Random random;

    public LifeUp() {
        paint = new Paint();
        paint.setColor(Color.rgb(230,0,0));
        paint.setAntiAlias(false);
        random = new Random();
        getlifeup();
    }
    public void getlifeup(){
        lifeY = TouchBallView.dHeight + 21;
        lifeX = random.nextInt(TouchBallView.dWidth);
        lifespeed = 30 +random.nextInt(10);
    }

}
