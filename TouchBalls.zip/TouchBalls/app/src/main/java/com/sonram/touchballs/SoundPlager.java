package com.sonram.touchballs;

import android.content.Context;
import android.media.AudioManager;
import android.media.SoundPool;

public class SoundPlager {

    private static SoundPool soundPool;
    private static int hitSound,hitSound2;
    private static int overSound;

    public SoundPlager(Context context){
        soundPool = new SoundPool(2, AudioManager.STREAM_MUSIC,0);

        hitSound = soundPool.load(context,R.raw.raser1,1);
        hitSound2 = soundPool.load(context,R.raw.laser3,1);
        overSound = soundPool.load(context,R.raw.over,1);


    }

    public void playhitsound(){
        soundPool.play(hitSound,1.0f,1.0f,1,0,1.0f);
    }

    public void playoversound(){
        soundPool.play(overSound,1.0f,1.0f,1,0,1.0f);
    }
    public void playhitsond2(){
        soundPool.play(hitSound2,1.0f,1.0f,1,0,1.0f);
    }
}
