package com.sonram.touchballs;

import android.content.Context;
import android.graphics.Color;
import android.graphics.Paint;

import java.util.Random;

public class BallLeft {
    Paint paint;
    int ballLX,ballLY=500,ballLspeed;
    Random random;

    public BallLeft(Context context){
        paint = new Paint();
        paint.setColor(Color.rgb(255,106,77));
        paint.setAntiAlias(false);
        random = new Random();
        getballleft();
    }

    public void getballleft(){
        ballLX = -(TouchBallView.dWidth+21);
        ballLY = random.nextInt(TouchBallView.dHeight);
        ballLspeed = 5 +random.nextInt(10);
    }
}
