package com.sonram.touchballs;

import android.content.Context;

import java.util.Random;

public class CloundL {

    int cloundX,cloundY,cloundSpeed;
    Random random;

    public CloundL(Context context) {
        random = new Random();
        getclound();

    }

    public void getclound(){
        cloundX = -(TouchBallView.dWidth+21);
        cloundY = random.nextInt(1000);
        cloundSpeed = 2 +random.nextInt(2);
    }
}
