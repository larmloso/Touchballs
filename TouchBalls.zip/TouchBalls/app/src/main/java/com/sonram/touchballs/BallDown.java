package com.sonram.touchballs;

import android.content.Context;
import android.graphics.Color;
import android.graphics.Paint;

import java.util.Random;

public class BallDown {
    Paint paint;
    int ballDX,ballDY,ballDspeed;
    Random random;

    public BallDown(Context context){
        paint = new Paint();
        paint.setColor(Color.rgb(255,255,0));
        paint.setAntiAlias(false);
        random = new Random();
        getballdown();
    }

    public void getballdown(){
        ballDY = -(TouchBallView.dHeight);
        ballDX = random.nextInt(TouchBallView.dWidth);
        ballDspeed = 6 + random.nextInt(12);

    }
}
