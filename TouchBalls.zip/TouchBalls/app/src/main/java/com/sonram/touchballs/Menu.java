package com.sonram.touchballs;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

public class Menu extends AppCompatActivity {
    private long backPresendTime;
    private Button btstart;
    Animation abtstart,aimgview;
    ImageView imageView;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        this.requestWindowFeature(Window.FEATURE_NO_TITLE);
        this.getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,WindowManager.LayoutParams.FLAG_FULLSCREEN);
        this.getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        setContentView(R.layout.activity_menu);

        btstart = findViewById(R.id.start);
        imageView = findViewById(R.id.imageView);

        abtstart = AnimationUtils.loadAnimation(this,R.anim.btstart);
        aimgview = AnimationUtils.loadAnimation(this,R.anim.btexit);
        btstart.startAnimation(abtstart);
        imageView.startAnimation(aimgview);


    }
    public void startGame(View view){
        Intent intent = new Intent(this,GameView.class);
        startActivity(intent);
        finish();
    }

    @Override
    public void onBackPressed() {
        if(backPresendTime + 2000 > System.currentTimeMillis()){
            super.onBackPressed();
            return;
        }
        else {
            Toast.makeText(getBaseContext(),"Press back again to exit",Toast.LENGTH_SHORT).show();
        }
        backPresendTime = System.currentTimeMillis();
    }

}
