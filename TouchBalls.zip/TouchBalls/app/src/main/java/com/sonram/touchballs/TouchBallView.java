package com.sonram.touchballs;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Point;
import android.graphics.Rect;
import android.graphics.Typeface;
import android.view.Display;
import android.view.MotionEvent;
import android.view.View;
import java.util.ArrayList;
import java.util.Random;

public class TouchBallView extends View {

    static int dWidth,dHeight;
    Random random;
    int couX,couY;
    int score,life = 3;
    private Bitmap background,clound1,clound2;
    private Rect rect;
    private boolean heart = false;

    public SoundPlager sound;

    ArrayList<BallRight> ballright;
    ArrayList<BallUp> ballup;
    ArrayList<BallDown> balldown;
    ArrayList<BallLeft> ballLefts;
    ArrayList<SmallBR> smallBRS;
    ArrayList<KillballRight> kills;
    ArrayList<LifeUp> lifes;
    ArrayList<Clound> clounds;
    ArrayList<CloundL> cloundLS;

    private Paint scorPaint = new Paint();


    public TouchBallView(Context context) {
        super(context);

        sound = new SoundPlager(context);


        Display display = ((Activity) getContext()).getWindowManager().getDefaultDisplay();
        Point size = new Point();
        display.getSize(size);
        dWidth = size.x;
        dHeight = size.y;

        random = new Random();

        background = BitmapFactory.decodeResource(getResources(), R.drawable.bg5);
        clound1 = BitmapFactory.decodeResource(getResources(),R.drawable.clound1);
        clound2 = BitmapFactory.decodeResource(getResources(),R.drawable.clound2);

        rect = new Rect(0,0,dWidth,dHeight);

        scorPaint.setColor(Color.rgb(0,64,77));
        scorPaint.setTextSize(70);
        scorPaint.setTypeface(Typeface.DEFAULT_BOLD);
        scorPaint.setAntiAlias(true);


        ballright = new ArrayList<>();
        ballLefts = new ArrayList<>();
        ballup = new ArrayList<>();
        balldown = new ArrayList<>();
        smallBRS = new ArrayList<>();
        kills = new ArrayList<>();
        lifes = new ArrayList<>();
        clounds = new ArrayList<>();
        cloundLS = new ArrayList<>();

        for(int i=0;i<2;i++) {
            BallRight ballRight = new BallRight(context);
            ballright.add(ballRight);

            BallLeft ballLeft = new BallLeft(context);
            ballLefts.add(ballLeft);

            SmallBR smallBR = new SmallBR();
            smallBRS.add(smallBR);

            Clound clound = new Clound(context);
            clounds.add(clound);

            CloundL cloundL = new CloundL(context);
            cloundLS.add(cloundL);

        }

        for(int e=0;e<3;e++){
            BallUp ballUp = new BallUp(context);
            ballup.add(ballUp);

            BallDown ballDown = new BallDown(context);
            balldown.add(ballDown);

            KillballRight killballRight = new KillballRight();
            kills.add(killballRight);

        }

        LifeUp killballUp = new LifeUp();
        lifes.add(killballUp);






    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);

        canvas.drawBitmap(background, null, rect, null);




        for(int i=0;i<ballright.size();i++) {

            canvas.drawBitmap(clound1,cloundLS.get(i).cloundX,cloundLS.get(i).cloundY,null);
            cloundLS.get(i).cloundX += cloundLS.get(i).cloundSpeed;
            if(cloundLS.get(i).cloundX > dWidth){
                cloundLS.get(i).getclound();
            }

            canvas.drawBitmap(clound2,clounds.get(i).cloudnX,clounds.get(i).cloundY,null);
            clounds.get(i).cloudnX -= clounds.get(i).cloundSpeed;
            if(clounds.get(i).cloudnX < 0){
                clounds.get(i).getclound();
            }

            canvas.drawCircle(ballright.get(i).ballRX,ballright.get(i).ballRY,55+(random.nextInt(5)),ballright.get(i).paint);
            ballright.get(i).ballRX -= ballright.get(i).ballRspeed;
            if (ballright.get(i).ballRX < 0){
                ballright.get(i).getBallRight();
            }

            canvas.drawCircle(smallBRS.get(i).smallRX,smallBRS.get(i).smallRY,25+(random.nextInt(5)),smallBRS.get(i).paint);
            smallBRS.get(i).smallRX -= smallBRS.get(i).smallRspeed;
            if (smallBRS.get(i).smallRX < 0){
                smallBRS.get(i).getsmallBR();
            }

            canvas.drawCircle(ballLefts.get(i).ballLX,ballLefts.get(i).ballLY,50+(random.nextInt(5)),ballLefts.get(i).paint);
            ballLefts.get(i).ballLX += ballLefts.get(i).ballLspeed;
            if (ballLefts.get(i).ballLX > dWidth){
                ballLefts.get(i).getballleft();
            }

            if (ballcheckright(ballright.get(i).ballRX,ballright.get(i).ballRY)){
                canvas.drawCircle(ballright.get(i).ballRX,ballright.get(i).ballRY,200,ballright.get(i).paint);
                ballright.get(i).ballRY = -100;
                score += 10;
                sound.playhitsound();
            }

            if (ballcheckright(smallBRS.get(i).smallRX,smallBRS.get(i).smallRY)){
                canvas.drawCircle(smallBRS.get(i).smallRX,smallBRS.get(i).smallRY,200,smallBRS.get(0).paint);
                smallBRS.get(i).smallRY = -100;
                score += 10;
                sound.playhitsound();
            }

            if (ballcheckleft(ballLefts.get(i).ballLX,ballLefts.get(i).ballLY)){
                canvas.drawCircle(ballLefts.get(i).ballLX,ballLefts.get(i).ballLY,200,ballLefts.get(i).paint);
                ballLefts.get(i).ballLY = -100;
                score += 10;
                sound.playhitsound();
            }
        }

        for(int e=0;e<ballup.size();e++){

            canvas.drawCircle(ballup.get(e).ballupX,ballup.get(e).ballupY,55+(random.nextInt(5)),ballup.get(e).paint);
            ballup.get(e).ballupY -= ballup.get(e).ballupSpeed;
            if (ballup.get(e).ballupY < 0) {
                ballup.get(e).getballup();
            }

            canvas.drawCircle(balldown.get(e).ballDX,balldown.get(e).ballDY,50+(random.nextInt(5)),balldown.get(e).paint);
            balldown.get(e).ballDY += balldown.get(e).ballDspeed;
            if (balldown.get(e).ballDY > dHeight){
                balldown.get(e).getballdown();
            }

            if (ballcheckup(ballup.get(e).ballupX,ballup.get(e).ballupY)){
                canvas.drawCircle(ballup.get(e).ballupX,ballup.get(e).ballupY,200,ballup.get(e).paint);
                ballup.get(e).ballupX = -100;
                score += 10;
                sound.playhitsond2();
            }
            if (ballcheckdown(balldown.get(e).ballDX,balldown.get(e).ballDY)){
                canvas.drawCircle(balldown.get(e).ballDX,balldown.get(e).ballDY,200,balldown.get(e).paint);
                balldown.get(e).ballDX = -100;
                score += 10;
                sound.playhitsond2();
            }
        }
        for(int k=0;k<kills.size();k++){
            if(score > 100){
                canvas.drawCircle(kills.get(k).kbX,kills.get(k).kbY,40+(random.nextInt(5)),kills.get(k).paint);
                kills.get(k).kbX -= kills.get(k).kbSpeed;
                if (kills.get(k).kbX < 0){
                    kills.get(k).getkillbR();
                }
            }


            if (ballcheckright(kills.get(k).kbX,kills.get(k).kbY)){
                canvas.drawCircle(kills.get(k).kbX,kills.get(k).kbY,200,kills.get(k).paint);
                kills.get(k).kbY = -100;
                sound.playoversound();
                life -=1;
                if(life == 0){
                    Intent over = new Intent(getContext(),OverGame.class);
                    over.putExtra("score", score);
                    over.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                    getContext().startActivity(over);
                }
            }


        }

        for(int h=0;h<lifes.size();h++){

            if(life < 3 && random.nextInt(500) == 1){
                heart = true;
            }
            if (heart){
                canvas.drawCircle(lifes.get(h).lifeX,lifes.get(h).lifeY,40+(random.nextInt(5)),lifes.get(h).paint);
                lifes.get(h).lifeY -= lifes.get(h).lifespeed;
                if (lifes.get(h).lifeY < 0) {
                    lifes.get(h).getlifeup();
                    heart = false;
                }

            }
            if (ballcheckup(lifes.get(h).lifeX,lifes.get(h).lifeY)){
                canvas.drawCircle(lifes.get(h).lifeX,lifes.get(h).lifeY,200,lifes.get(h).paint);
                lifes.get(h).lifeX = -100;
                sound.playoversound();
                life += 1;
                heart = false;
            }

        }
        couX = 0;
        couY = 0;
        canvas.drawText("Score : "+ score,100,100,scorPaint);
        canvas.drawText("Life : "+ life,700,100,scorPaint);

    }

    public boolean ballcheckright(int x,int y){
        if((couX) < (x+60) && (x+60) < (couX+40) && (couY) < (y+50) && (y+50) < (couY+40)){ return true; }
        if(couX < (x) && x < (couX+40) && couY < (y) && y < (couY+40)){ return true; }
        return false;
    }
    public boolean ballcheckup(int x,int y){
        if(couY > y && y > (couY-40) && couX > x && x > (couX-40)){ return true; }
        return false;
    }
    public boolean ballcheckdown(int x,int y){
        if((couX) < (x+50) && (x+50) < (couX+40) && (couY) < (y+55) && (y+55) < (couY+40)){ return true; }
        if(couX < (x) && x < (couX+40) && couY < (y) && y < (couY+40)){ return true; }
        return false;
    }
    public boolean ballcheckleft(int x,int y){
        if(couY > y && y > (couY-40) && couX > x && x > (couX-40)){ return true; }
        return false;
    }

    @Override
    public boolean onTouchEvent(MotionEvent event) {
        switch(event.getAction()){
            case MotionEvent.ACTION_DOWN:
                couX = Math.round(event.getX());
                couY = Math.round(event.getY());

            case MotionEvent.ACTION_MOVE:
                couX = Math.round(event.getX());
                couY = Math.round(event.getY());

            case MotionEvent.ACTION_CANCEL:
                couX = Math.round(event.getX());
                couY = Math.round(event.getY());

            case MotionEvent.ACTION_UP:
                couX = Math.round(event.getX());
                couY = Math.round(event.getY());
        }

        return true;
    }

}
