package com.sonram.touchballs;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class OverGame extends AppCompatActivity {

    private long backPresendTime;
    TextView textView,textView2;
    String score;
    int highscore = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        this.requestWindowFeature(Window.FEATURE_NO_TITLE);
        this.getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,WindowManager.LayoutParams.FLAG_FULLSCREEN);
        this.getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_over_game);

        textView2 = (TextView) findViewById(R.id.textView2);
        textView = findViewById(R.id.score);

        score = getIntent().getExtras().get("score").toString();
        textView.setText("Score : " + score);


        SharedPreferences myScore = this.getSharedPreferences("MyAwesomeScore", Context.MODE_PRIVATE);
        highscore = myScore.getInt("score", 0);
        textView2.setText("High Score : " + highscore);

        if(Integer.parseInt(score)> highscore) {
            highscore = Integer.parseInt(score);
            SharedPreferences.Editor editor = myScore.edit();
            editor.putInt("score", highscore);
            editor.commit();
            textView2.setText("High Score : " + highscore);
        }

    }

    public void playagain(View view){
        Intent intent = new Intent(this,GameView.class);
        startActivity(intent);
        finish();
    }
    public void menu(View view){
        Intent intent = new Intent(this,Menu.class);
        startActivity(intent);
        finish();
    }

    @Override
    public void onBackPressed() {
        if(backPresendTime + 2000 > System.currentTimeMillis()){
            super.onBackPressed();
            return;
        }
        else {
            Toast.makeText(getBaseContext(),"Press back again to exit",Toast.LENGTH_SHORT).show();
        }
        backPresendTime = System.currentTimeMillis();
    }
}
